package com.airguard.eusebio.teacher;

import android.app.Activity;
import android.content.ContentValues;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void toast(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public void exportCsv(String csv) {
            try {
                String name = "AirGuard_Data_Record_" + System.currentTimeMillis() + ".csv";
                OutputStream out = createDownload(name, "text/csv");
                out.write(csv.getBytes(StandardCharsets.UTF_8));
                out.close();
                showLong("CSV saved in Downloads/AirGuard");
            } catch (Exception e) {
                showLong("CSV export failed: " + e.getMessage());
            }
        }

        @JavascriptInterface
        public void exportXlsx(String payloadJson, String chartDataUrl) {
            try {
                JSONObject payload = new JSONObject(payloadJson);
                byte[] chartPng = decodeDataUrl(chartDataUrl);
                byte[] workbook = buildWorkbook(payload, chartPng);
                String range = safeFilePart(payload.optString("range", "DATA"));
                String name = "AirGuard_" + range + "_Report_" + System.currentTimeMillis() + ".xlsx";
                OutputStream out = createDownload(name, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                out.write(workbook);
                out.close();
                showLong("Excel report saved in Downloads/AirGuard");
            } catch (Exception e) {
                showLong("Excel export failed: " + e.getMessage());
            }
        }
    }

    private OutputStream createDownload(String name, String mime) throws Exception {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, name);
            values.put(MediaStore.Downloads.MIME_TYPE, mime);
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AirGuard");
            android.net.Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("Cannot create download file");
            OutputStream out = getContentResolver().openOutputStream(uri);
            if (out == null) throw new Exception("Cannot open download file");
            return out;
        }
        File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "AirGuard");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("Cannot create AirGuard folder");
        return new FileOutputStream(new File(dir, name));
    }

    private void showLong(String message) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
    }

    private static String safeFilePart(String s) {
        return s == null ? "DATA" : s.replaceAll("[^A-Za-z0-9_-]", "_");
    }

    private static byte[] decodeDataUrl(String value) {
        if (value == null || value.isEmpty()) return new byte[0];
        int comma = value.indexOf(',');
        String b64 = comma >= 0 ? value.substring(comma + 1) : value;
        return Base64.decode(b64, Base64.DEFAULT);
    }

    private static byte[] buildWorkbook(JSONObject payload, byte[] chartPng) throws Exception {
        JSONArray records = payload.optJSONArray("records");
        if (records == null) records = new JSONArray();
        String school = payload.optString("school", "Eusebio High School");
        String app = payload.optString("app", "AirGuard Teacher");
        String range = payload.optString("range", "DATA");
        String generatedAt = payload.optString("generatedAt", new Date().toString());

        double sumAqi = 0, sumTemp = 0;
        double minAqi = Double.POSITIVE_INFINITY, maxAqi = Double.NEGATIVE_INFINITY;
        double minTemp = Double.POSITIVE_INFINITY, maxTemp = Double.NEGATIVE_INFINITY;
        int normal = 0, warning = 0, critical = 0, purifierOn = 0;
        for (int i = 0; i < records.length(); i++) {
            JSONObject r = records.optJSONObject(i);
            if (r == null) continue;
            double aqi = r.optDouble("aqi", 0);
            double temp = r.optDouble("temp", 0);
            sumAqi += aqi; sumTemp += temp;
            minAqi = Math.min(minAqi, aqi); maxAqi = Math.max(maxAqi, aqi);
            minTemp = Math.min(minTemp, temp); maxTemp = Math.max(maxTemp, temp);
            String status = r.optString("status", "Normal");
            if ("Critical".equalsIgnoreCase(status)) critical++;
            else if ("Warning".equalsIgnoreCase(status)) warning++;
            else normal++;
            if ("ON".equalsIgnoreCase(r.optString("purifier"))) purifierOn++;
        }
        int count = records.length();
        double avgAqi = count == 0 ? 0 : sumAqi / count;
        double avgTemp = count == 0 ? 0 : sumTemp / count;
        if (count == 0) { minAqi = maxAqi = minTemp = maxTemp = 0; }

        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        ZipOutputStream zip = new ZipOutputStream(bytes);

        put(zip, "[Content_Types].xml", contentTypes(chartPng.length > 0));
        put(zip, "_rels/.rels", rootRels());
        put(zip, "docProps/core.xml", coreProps(app));
        put(zip, "docProps/app.xml", appProps());
        put(zip, "xl/workbook.xml", workbookXml());
        put(zip, "xl/_rels/workbook.xml.rels", workbookRels());
        put(zip, "xl/styles.xml", stylesXml());
        put(zip, "xl/worksheets/sheet1.xml", summarySheet(school, app, range, generatedAt, count, avgAqi, minAqi, maxAqi, avgTemp, minTemp, maxTemp, normal, warning, critical, purifierOn, chartPng.length > 0));
        put(zip, "xl/worksheets/sheet2.xml", dataSheet(records));
        if (chartPng.length > 0) {
            put(zip, "xl/worksheets/_rels/sheet1.xml.rels", summarySheetRels());
            put(zip, "xl/drawings/drawing1.xml", drawingXml());
            put(zip, "xl/drawings/_rels/drawing1.xml.rels", drawingRels());
            put(zip, "xl/media/image1.png", chartPng);
        }
        zip.finish();
        zip.close();
        return bytes.toByteArray();
    }

    private static void put(ZipOutputStream zip, String name, String text) throws Exception {
        put(zip, name, text.getBytes(StandardCharsets.UTF_8));
    }

    private static void put(ZipOutputStream zip, String name, byte[] data) throws Exception {
        ZipEntry entry = new ZipEntry(name);
        zip.putNextEntry(entry);
        zip.write(data);
        zip.closeEntry();
    }

    private static String contentTypes(boolean image) {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                (image ? "<Default Extension=\"png\" ContentType=\"image/png\"/>" : "") +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                "<Override PartName=\"/xl/worksheets/sheet2.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
                (image ? "<Override PartName=\"/xl/drawings/drawing1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.drawing+xml\"/>" : "") +
                "<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>" +
                "<Override PartName=\"/docProps/app.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.extended-properties+xml\"/>" +
                "</Types>";
    }

    private static String rootRels() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
                "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>" +
                "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties\" Target=\"docProps/app.xml\"/>" +
                "</Relationships>";
    }

    private static String coreProps(String app) {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        String now = f.format(new Date());
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:dcterms=\"http://purl.org/dc/terms/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" +
                "<dc:creator>" + xml(app) + "</dc:creator><cp:lastModifiedBy>" + xml(app) + "</cp:lastModifiedBy>" +
                "<dcterms:created xsi:type=\"dcterms:W3CDTF\">" + now + "</dcterms:created><dcterms:modified xsi:type=\"dcterms:W3CDTF\">" + now + "</dcterms:modified></cp:coreProperties>";
    }

    private static String appProps() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Properties xmlns=\"http://schemas.openxmlformats.org/officeDocument/2006/extended-properties\" xmlns:vt=\"http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes\"><Application>AirGuard Android</Application></Properties>";
    }

    private static String workbookXml() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>" +
                "<sheet name=\"Summary\" sheetId=\"1\" r:id=\"rId1\"/><sheet name=\"Data\" sheetId=\"2\" r:id=\"rId2\"/>" +
                "</sheets></workbook>";
    }

    private static String workbookRels() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
                "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet2.xml\"/>" +
                "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
                "</Relationships>";
    }

    private static String stylesXml() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
                "<fonts count=\"3\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"20\"/><color rgb=\"FF08752E\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><color rgb=\"FFFFFFFF\"/><name val=\"Calibri\"/></font></fonts>" +
                "<fills count=\"4\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF08752E\"/><bgColor indexed=\"64\"/></patternFill></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFE9F8EE\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>" +
                "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
                "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
                "<cellXfs count=\"5\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"2\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyAlignment=\"1\"><alignment horizontal=\"center\"/></xf><xf numFmtId=\"0\" fontId=\"0\" fillId=\"3\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"2\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/></cellXfs>" +
                "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>";
    }

    private static String summarySheet(String school, String app, String range, String generatedAt, int count,
                                       double avgAqi, double minAqi, double maxAqi, double avgTemp, double minTemp, double maxTemp,
                                       int normal, int warning, int critical, int purifierOn, boolean hasImage) {
        StringBuilder x = new StringBuilder();
        x.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
        x.append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">");
        x.append("<cols><col min=\"1\" max=\"1\" width=\"24\" customWidth=\"1\"/><col min=\"2\" max=\"6\" width=\"18\" customWidth=\"1\"/></cols><sheetData>");
        x.append(row(1, textCell("A1", app + " Environmental Report", 1)));
        x.append(row(2, textCell("A2", school, 3)));
        x.append(row(3, textCell("A3", "Selected range", 0) + textCell("B3", range, 3) + textCell("D3", "Generated", 0) + textCell("E3", generatedAt, 0)));
        x.append(row(5, textCell("A5", "Metric", 2) + textCell("B5", "Value", 2) + textCell("D5", "Status count", 2) + textCell("E5", "Value", 2)));
        x.append(row(6, textCell("A6", "Records", 0) + numCell("B6", count, 0) + textCell("D6", "Normal", 0) + numCell("E6", normal, 0)));
        x.append(row(7, textCell("A7", "Average AQI", 0) + numCell("B7", avgAqi, 4) + textCell("D7", "Warning", 0) + numCell("E7", warning, 0)));
        x.append(row(8, textCell("A8", "AQI min / max", 0) + textCell("B8", String.format(Locale.US, "%.0f / %.0f", minAqi, maxAqi), 0) + textCell("D8", "Critical", 0) + numCell("E8", critical, 0)));
        x.append(row(9, textCell("A9", "Average temperature", 0) + numCell("B9", avgTemp, 4) + textCell("D9", "Purifier ON readings", 0) + numCell("E9", purifierOn, 0)));
        x.append(row(10, textCell("A10", "Temperature min / max", 0) + textCell("B10", String.format(Locale.US, "%.1f°C / %.1f°C", minTemp, maxTemp), 0)));
        x.append("</sheetData><mergeCells count=\"2\"><mergeCell ref=\"A1:F1\"/><mergeCell ref=\"A2:F2\"/></mergeCells>");
        x.append("<pageMargins left=\"0.3\" right=\"0.3\" top=\"0.5\" bottom=\"0.5\" header=\"0.2\" footer=\"0.2\"/><pageSetup orientation=\"landscape\" fitToWidth=\"1\" fitToHeight=\"0\"/>");
        if (hasImage) x.append("<drawing r:id=\"rId1\"/>");
        x.append("</worksheet>");
        return x.toString();
    }

    private static String dataSheet(JSONArray records) {
        StringBuilder x = new StringBuilder(2048 + records.length() * 260);
        x.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><cols>");
        x.append("<col min=\"1\" max=\"1\" width=\"24\" customWidth=\"1\"/><col min=\"2\" max=\"3\" width=\"15\" customWidth=\"1\"/><col min=\"4\" max=\"5\" width=\"14\" customWidth=\"1\"/><col min=\"6\" max=\"6\" width=\"48\" customWidth=\"1\"/></cols><sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews><sheetData>");
        x.append(row(1, textCell("A1", "Date & Time", 2) + textCell("B1", "Air Quality (AQI)", 2) + textCell("C1", "Temperature (°C)", 2) + textCell("D1", "Purifier", 2) + textCell("E1", "Status", 2) + textCell("F1", "Remarks", 2)));
        for (int i = 0; i < records.length(); i++) {
            JSONObject r = records.optJSONObject(i); if (r == null) continue;
            int row = i + 2;
            String cells = textCell("A" + row, r.optString("t"), 0) +
                    numCell("B" + row, r.optDouble("aqi", 0), 0) +
                    numCell("C" + row, r.optDouble("temp", 0), 4) +
                    textCell("D" + row, r.optString("purifier"), 0) +
                    textCell("E" + row, r.optString("status"), 0) +
                    textCell("F" + row, r.optString("remarks"), 0);
            x.append(row(row, cells));
        }
        x.append("</sheetData><autoFilter ref=\"A1:F" + Math.max(1, records.length() + 1) + "\"/><pageMargins left=\"0.3\" right=\"0.3\" top=\"0.5\" bottom=\"0.5\" header=\"0.2\" footer=\"0.2\"/></worksheet>");
        return x.toString();
    }

    private static String summarySheetRels() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing\" Target=\"../drawings/drawing1.xml\"/></Relationships>";
    }

    private static String drawingXml() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<xdr:wsDr xmlns:xdr=\"http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
                "<xdr:twoCellAnchor><xdr:from><xdr:col>0</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>11</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from><xdr:to><xdr:col>10</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>31</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to>" +
                "<xdr:pic><xdr:nvPicPr><xdr:cNvPr id=\"2\" name=\"AirGuard Trend Chart\"/><xdr:cNvPicPr/></xdr:nvPicPr><xdr:blipFill><a:blip r:embed=\"rId1\"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill><xdr:spPr><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic><xdr:clientData/></xdr:twoCellAnchor></xdr:wsDr>";
    }

    private static String drawingRels() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"../media/image1.png\"/></Relationships>";
    }

    private static String row(int r, String cells) { return "<row r=\"" + r + "\">" + cells + "</row>"; }
    private static String textCell(String ref, String value, int style) { return "<c r=\"" + ref + "\" s=\"" + style + "\" t=\"inlineStr\"><is><t>" + xml(value) + "</t></is></c>"; }
    private static String numCell(String ref, double value, int style) { return "<c r=\"" + ref + "\" s=\"" + style + "\" t=\"n\"><v>" + String.format(Locale.US, "%.4f", value) + "</v></c>"; }
    private static String xml(String s) { if (s == null) return ""; return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;"); }
}
