plugins {
    id("com.android.application")
}

android {
    namespace = "com.airguard.eusebio.teacher"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.airguard.eusebio.teacher"
        minSdk = 24
        targetSdk = 35
        versionCode = 2
        versionName = "1.1-demo"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
