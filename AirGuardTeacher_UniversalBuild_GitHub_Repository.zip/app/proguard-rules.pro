# AirGuard demo app - no custom ProGuard rules required.
