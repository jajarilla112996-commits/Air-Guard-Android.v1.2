# AirGuard Teacher – Demo Android App

Demo Teacher-side Android app for the **Eusebio High School AirGuard** prototype.

This repository is intentionally in **demo mode** so the interface and behavior can be reviewed before the Arduino UNO R4 WiFi integration is finalized.

## Current demo rules

### Air quality (MQ-135 demo index)
- **GOOD:** 0–250 → purifier **OFF**
- **MILD:** 251–450 → purifier **ON**
- **CRITICAL:** 451+ → purifier **ON** + critical status

### Temperature
- **NORMAL:** below 40.0 °C
- **WARNING:** 40.0–41.9 °C
- **CRITICAL:** 42.0 °C and above

Temperature currently changes the classroom warning status but **does not control the purifier**.

## Teacher app features
- Teacher Dashboard
- MQ-135 air-quality demo monitoring
- Temperature demo monitoring
- Automatic purifier status based on air quality
- Teacher Quick Actions:
  - Medical Alert
  - Request Guard
  - Faculty Assistance
- Separate Send Message targets:
  - Guard
  - Teacher
  - Faculty
- Data Record / logs
- Crypto-style interactive history chart with 1H / 6H / 24H / 7D / 1M / 3M / 1Y / MAX ranges
- Chart pan, zoom, point inspection, AQI/temperature toggles, and expanded view
- CSV export
- Excel `.xlsx` export with a Summary sheet, filtered Data sheet, and embedded chart image
- Alert history
- Demo sliders for testing different AQI and temperature conditions

## Browser preview

Open:

`demo/AirGuard_Teacher_Demo.html`

This lets you check the interface without installing the APK. The browser preview includes the enhanced interactive chart. Excel + graph export is implemented in the Android APK bridge; browser preview falls back to CSV.

## Build APK using GitHub Actions

The repository includes:

`.github/workflows/android.yml`

After uploading the project to GitHub:

1. Open the repository.
2. Go to **Actions**.
3. Select **Build AirGuard Teacher APK**.
4. Choose **Run workflow**.
5. Wait for the build to complete.
6. Open the completed workflow run.
7. Under **Artifacts**, download **AirGuard-Teacher-Demo-APK**.
8. Extract the ZIP and install `app-debug.apk` on the Android phone.

A build also runs automatically when changes are pushed to the `main` branch.

## Open locally in Android Studio

Open the repository root as an Android Studio project. The app module is `app`.

- Package: `com.airguard.eusebio.teacher`
- Minimum Android version: API 24
- Target / compile SDK: API 35
- Android Gradle Plugin: 8.7.3
- GitHub Actions Gradle: 8.9

## Arduino UNO R4 WiFi integration

The demo already reserves the future HTTP connection flow. When the hardware firmware is finalized, the app can receive live values from the UNO R4 WiFi instead of the demo sliders.

Planned example endpoint:

`GET /api/status`

Example response:

```json
{
  "aqi": 186,
  "temperature": 36.8
}
```

The Guard and Faculty apps will be separated later after their alert conditions and permissions are finalized.

## App branding update
- Android launcher icon now uses the approved Eusebio High School + Air Guard logo.
- The in-app Teacher Dashboard header uses the same Air Guard branding.
